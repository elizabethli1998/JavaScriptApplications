package ChatApplication;

import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;
 
public class Server 
{
	public static ArrayList<ClientSide> clients = new ArrayList<>();
	public static void main(String[] args) throws IOException 
    {
		ServerSocket serverSocket = new ServerSocket(6666);
		 while (true) 
	     {
			 Socket socket = null;
			 try
			 {
				 socket = serverSocket.accept();
				 DataOutputStream out = new DataOutputStream(socket.getOutputStream());
				 DataInputStream in = new DataInputStream(socket.getInputStream());		
				 String name = in.readUTF();
				 ClientSide threadForClient = new ClientSide(socket, in, out, name);
				 clients.add(threadForClient);
				 threadForClient.start();
			 }
			 catch(Exception exp)
			 {
				 socket.close();
				 exp.printStackTrace();
			 }
	     }
    }
	public static void messageHistory(String name, String message) throws IOException
	{
		for(int i = 0; i < clients.size(); i++)
		{
			if(!clients.get(i).name.equals(name))
			{
				clients.get(i).out.writeUTF(message);
			}
		}
	}
}
class ClientSide extends Thread
{
	final DataOutputStream out;
	final Socket socket;
	final DataInputStream in;
	String name;
	
    public ClientSide(Socket socket, DataInputStream in, DataOutputStream out, String name) 
    {
    	this.out = out;
        this.name = name;
        this.socket = socket;
        this.in = in;
      
    }
    @Override
    public void run() 
    {
    	while (true) 
        {
            try 
            {
             String message = in.readUTF();
             String textDetails = name + ": " + message;
             System.out.println(textDetails);
             Server.messageHistory(name, textDetails);
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
    }
}