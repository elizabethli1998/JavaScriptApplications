This project contains the Chat Application process with both Server and Client.

To run the program: 

Unzip the contents of the package first and import it onto anything that runs Java, preferably Eclipse.

Then run Server.Java first.

Run Client.java afterwards. 

You can then pin different clients on the console to see how this project works with different users.
