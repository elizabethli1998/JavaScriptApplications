package ChatApplication;
import java.net.*;
import java.io.BufferedReader;
import java.io.*;
public class Client {
	  public static void main(String[] args) throws IOException 
	    {
	        try
	        {
	        	BufferedReader scannedInput = new BufferedReader(new InputStreamReader(System.in));
	        	System.out.println(">Enter a name:");
	        	String name = scannedInput.readLine();
	        	name.trim();        	
	            InetAddress ip = InetAddress.getByName("localhost");
	            Socket socket = new Socket(ip, 6666);
	            System.out.println(name+ " is connected to server!");
	            System.out.println(">Send a message");
	            DataInputStream in = new DataInputStream(socket.getInputStream());
	            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
	            out.writeUTF(name);
	            while (true) 
	            {	
	            	if(scannedInput.ready())
	            	{
	            		 String tosend = scannedInput.readLine();
	            		 out.writeUTF(tosend);
	    	                if(tosend.equals("Exit"))
	    	                {
	    	                    System.out.println("Closing connection : " + socket);
	    	                    socket.close();
	    	                    System.out.println(name + " has logged off!");
	    	                    break;
	    	                }
	            	}
	            	if(in.available() > 0)
	            	{
	            		System.out.println(in.readUTF());
	            	}
	     
	            }
	            scannedInput.close();
	            in.close();
	            out.close();
	        }
	        catch(Exception e)
	        {
	            e.printStackTrace();
	        }
	   }
}
