var context = document.getElementById("canvas").getContext("2d");

var direction = 1;
var i = 0;
var j = 175;
var time;

function start()
{   context.fillStyle = '#FF0000';
    context.rect(1, 175, 7, 7);
    context.fill();
    if (document.getElementById("startOrStopBtn").value === "Start")
    {   document.getElementById("startOrStopBtn").value = "Stop"
        time = setInterval(drawSnake, 50);
    }
    else
    {   document.getElementById("startOrStopBtn").value = "Start";
        clearInterval(time);
    }
}
function drawSnake()
{   switch (direction)
    { case 0:
            context.rect(i, j, 7, 7);
            j--;
            break;
        case 1:
            context.rect(i, j, 7, 7);
            i++;
            break;
        case 2:
            context.rect(i, j, 7, 7);
            j++;
            break;
        case 3:
            context.rect(i, j, 7, 7);
            i--;
            break;
    }
    context.fill();
}
function goRight()
{   direction += 1;
    if (direction < 0)
    { direction = 3;}
    if (direction > 3)
    { direction = 0;}
}
function goLeft()
{   direction -= 1;
    if (direction <0)
    {  direction = 3;}
    if (direction > 3)
    {  direction = 0;}
}
