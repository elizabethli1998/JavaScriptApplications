
var Calc =
{
    Model:
    {
        first: undefined,
        second: undefined,
        op: undefined,
        lastButtonHighlighted : undefined,
        memory : 0
    },
    View:
    {
        textRow: {id: "textRow", type: "text", value: "", onclick: ""},
        button7: {id: "button7", type: "button", value: 7, onclick: ""},
        button8: {id: "button8", type: "button", value: 8, onclick: ""},
        button9: {id: "button9", type: "button", value: 9, onclick: ""},
        plus: {id: "plus", type: "button", value: "+", onclick: ""},
        button4: {id: "button4", type: "button", value: 4, onclick: ""},
        button5: {id: "button5", type: "button", value: 5, onclick: ""},
        button6: {id: "button6", type: "button", value: 6, onclick: ""},
        minus: {id: "minus", type: "button", value: "-", onclick: ""},
        button1: {id: "button1", type: "button", value: 1, onclick: ""},
        button2: {id: "button2", type: "button", value: 2, onclick: ""},
        button3: {id: "button3", type: "button", value: 3, onclick: ""},
        multiply: {id: "multiply", type: "button", value: "*", onclick: ""},
        button0: {id: "button0", type: "button", value: 0, onclick: ""},
        decimal: {id: "decimal", type: "button", value: ".", onclick: ""},
        equals: {id: "equals", type: "button", value: "=", onclick: ""},
        divide: {id: "divide", type: "button", value: "/", onclick: ""},
        clear: {id: "clear", type: "button", value: "C", onclick: ""},
        btnMR: {id: "btnMR", type: "button", value: "MR", onclick: ""},
        btnMinus: {id: "btnMinus", type: "button", value: "M-", onclick: ""},
        btnMPlus: {id: "btnMPlus", type: "button", value: "M+", onclick: ""},
        btnMC: {id: "btnMC", type: "button", value: "MC", onclick: ""}
    },
    Controller:
    { operatorHandler : function (op)
        {
            switch (op)
            {
                case "+":
                    return parseFloat(Calc.Model.first) + parseFloat(Calc.Model.second);
                case "-":
                    return parseFloat(Calc.Model.first) - parseFloat(Calc.Model.second);
                case "*":
                    return parseFloat(Calc.Model.first) * parseFloat(Calc.Model.second);
                case "/":
                    return parseFloat(Calc.Model.first) / parseFloat(Calc.Model.second);
            }
        },
        buttonHandler : function (that)
        {
            if (Calc.Model.lastButtonHighlighted !== undefined)
            {
                Calc.Model.lastButtonHighlighted.style.color = "black";
            }
            that.style.color = "red";
            Calc.Model.lastButtonHighlighted = that;
        }
    },
    start: function ()
    {   Calc.attachHandlers();
        console.log(Calc.display());
        return Calc.display();
    },
    displayElement: function (element)
    {  var s = "<input ";
        s += " id=\"" + element.id + "\"";
        s += " type=\"" + element.type + "\"";
        s += " value= \"" + element.value + "\"";
        s += " onclick= \"" + element.onclick + "\"";
        s += ">";
        return s;
    },
    display: function ()
    {   var s;
        s = "<table id=\"myTable\" border=3>"
        s += "<tr><td>" + Calc.displayElement(Calc.View.textRow) + "</td></tr>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.button7);
        s += Calc.displayElement(Calc.View.button8);
        s += Calc.displayElement(Calc.View.button9);
        s += Calc.displayElement(Calc.View.plus);
        s += "</tr></td>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.button4);
        s += Calc.displayElement(Calc.View.button5);
        s += Calc.displayElement(Calc.View.button6);
        s += Calc.displayElement(Calc.View.minus);
        s += "</tr></td>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.button1);
        s += Calc.displayElement(Calc.View.button2);
        s += Calc.displayElement(Calc.View.button3);
        s += Calc.displayElement(Calc.View.multiply);
        s += "</tr></td>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.button0);
        s += Calc.displayElement(Calc.View.decimal);
        s += Calc.displayElement(Calc.View.equals);
        s += Calc.displayElement(Calc.View.divide);
        s += "</tr></td>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.clear);
        s += Calc.displayElement(Calc.View.btnMR);
        s += Calc.displayElement(Calc.View.btnMinus);
        s += Calc.displayElement(Calc.View.btnMPlus);
        s += "</tr></td>";
        s += "<tr><td>";
        s += Calc.displayElement(Calc.View.btnMC);
        s += "</tr></td></table>";
        return s;
    },
    attachHandlers: function ()
    {
        Calc.View.button0.onclick = "Calc.button0Handler()";
        Calc.View.button1.onclick = "Calc.button1Handler()";
        Calc.View.button2.onclick = "Calc.button2Handler()";
        Calc.View.button3.onclick = "Calc.button3Handler()";
        Calc.View.button4.onclick = "Calc.button4Handler()";
        Calc.View.button5.onclick = "Calc.button5Handler()";
        Calc.View.button6.onclick = "Calc.button6Handler()";
        Calc.View.button7.onclick = "Calc.button7Handler()";
        Calc.View.button8.onclick = "Calc.button8Handler()";
        Calc.View.button9.onclick = "Calc.button9Handler()";
        Calc.View.plus.onclick = "Calc.plusHandler()";
        Calc.View.minus.onclick = "Calc.minusHandler()";
        Calc.View.multiply.onclick = "Calc.multiplyHandler()";
        Calc.View.decimal.onclick = "Calc.decimalHandler()";
        Calc.View.equals.onclick = "Calc.equalsHandler()";
        Calc.View.divide.onclick = "Calc.divideHandler()";
        Calc.View.clear.onclick = "Calc.clearHandler()";
        Calc.View.btnMR.onclick = "Calc.btnMRHandler()";
        Calc.View.btnMinus.onclick = "Calc.btnMinusHandler()";
        Calc.View.btnMPlus.onclick = "Calc.btnMPlusHandler()";
        Calc.View.btnMC.onclick = "Calc.btnMCHandler()";
    },
    button0Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button0"));
        document.getElementById("textRow").value += 0;
    },
    button1Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button1"));
        document.getElementById("textRow").value += 1;
    },
    button2Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button2"));
        document.getElementById("textRow").value += 2;
    },
    button3Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button3"));
        document.getElementById("textRow").value += 3;
    },
    button4Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button4"));
        document.getElementById("textRow").value += 4;
    },
    button5Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button5"));
        document.getElementById("textRow").value += 5;
    },
    button6Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button6"));
        document.getElementById("textRow").value += 6;
    },
    button7Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button7"));
        document.getElementById("textRow").value += 7;
    },
    button8Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button8"));
        document.getElementById("textRow").value += 8;
    },
    button9Handler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("button9"));
        document.getElementById("textRow").value += 9;
    },
    plusHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("plus"));
        Calc.Model.first = document.getElementById("textRow").value;
        document.getElementById("textRow").value = "";
        Calc.Model.op = "+";
    },
    minusHandler : function()
    {
		Calc.Controller.buttonHandler(document.getElementById("minus"));
		if (document.getElementById("textRow").value === "")
    {
			document.getElementById("textRow").value = "-";
		}
		else
    { Calc.Model.first = document.getElementById("textRow").value;
			document.getElementById("textRow").value = "";
			Calc.Model.op = "-";
		}
    },
    multiplyHandler : function()
    {   Calc.Controller.buttonHandler(document.getElementById("multiply"));
        Calc.Model.first = document.getElementById("textRow").value;
        document.getElementById("textRow").value = "";
        Calc.Model.op = "*";
    },
    divideHandler : function()
    {   Calc.Controller.buttonHandler(document.getElementById("divide"));
        Calc.Model.first = document.getElementById("textRow").value;
        document.getElementById("textRow").value = "";
        Calc.Model.op = "/";
    },
    decimalHandler : function()
    {   Calc.Controller.buttonHandler(document.getElementById("decimal"));
        document.getElementById("textRow").value += ".";
    },
    equalsHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("equals"));
        Calc.Model.second = document.getElementById("textRow").value;
        document.getElementById("textRow").value = Calc.Controller.operatorHandler(Calc.Model.op);
        Calc.Model.op = "";
        Calc.Model.first = "";
        Calc.Model.second = "";
    },
    btnMRHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("btnMR"));
        document.getElementById("textRow").value = Calc.Model.memory;
    },
    btnMinusHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("btnMinus"));
        Calc.Model.memory -= parseFloat(document.getElementById("textRow").value);
    },
    btnMPlusHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("btnMPlus"));
        Calc.Model.memory += parseFloat(document.getElementById("textRow").value);
    },
    btnMCHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("btnMC"));
        Calc.Model.memory = 0;
    },
    clearHandler: function ()
    {   Calc.Controller.buttonHandler(document.getElementById("clear"));
        document.getElementById("textRow").value = "";
        Calc.Model.first = "";
        Calc.Model.second = "";
    }

}
