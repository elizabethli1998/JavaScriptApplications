var readLine = require('readline-sync');
var firstBinaryNumber = readLine.question('Enter your first Binary Number: ');
var secondBinaryNumber = readLine.question('Enter your second Binary Number: ');
var operation = readLine.question('Input an operation that is either +,-,*,/,%,&,|,<<,>>, or ~ please: ');
if(operation != "<<" && operation != ">>" && operation != "~" && operation != "|" && operation != "&" )
{
  var firstNumber = toBinary(firstBinaryNumber.toString());
  var secondNumber = toBinary(secondBinaryNumber.toString());
  var result = firstNumber + operation + secondNumber
  var result = eval(result);
  console.log("Our result: " + result);
}
else
{
  if(operation == "<<")
  {
    console.log("Our left shift: " + left(firstBinaryNumber.toString()));
    console.log("Our left shift: " + left(secondBinaryNumber.toString()));
  }
  else if(operation == ">>")
  {
    console.log("Our right shift: " + right(firstBinaryNumber.toString()));
    console.log("Our right shift: " + right(secondBinaryNumber.toString()));
  }
  else if(operation == "|")
  {
    console.log("Our or operation result: " + doOr(firstBinaryNumber.toString(), secondBinaryNumber.toString()));
  }
  else if(operation == "&")
  {
    console.log("Our and operation result: " + doAnd(firstBinaryNumber.toString(), secondBinaryNumber.toString()));
  }
  else if(operation == "~")
  {
    console.log("Our result: " + doNot(firstBinaryNumber.toString()));
    console.log("Our result: " + doNot(secondBinaryNumber.toString()));
  }
}
function toBinary(binaryNum)
{
  var total = 0;
  var power = binaryNum.length-1;
  for(var i = 0; i < binaryNum.length; i++)
  {
    var newNum = parseInt(binaryNum.charAt(i));
    if(newNum == 1)
    {
      total = total + powerOf(power);
    }
    power--;
  }
  return total;
}
function powerOf(power)
{
  var total = 1;
  if(power == 0)
  {
    return total;
  }
  else
  {
    for(var i = 0; i < power; i++)
    {
      total = total * 2;
    }
  }
  return total;
}
function reverseNumber(num)
{
  var numReverse = num.split("").reverse();
  return numReverse.join("");
}
function right(num)
{
  return num.slice(0, num.length-1);
}
function left(num)
{
  return num + "0";
}
function doAnd (firstNumber, secondNumber)
{
  var length;
  var result = "";
  var lengthOfFirstNumber = firstNumber.length;
  var lengthOfSecondNumber = secondNumber.length;
  var difference = lengthOfFirstNumber - lengthOfSecondNumber;
  var finalfirstNumber = reverseNumber(firstNumber.toString());
  var finalsecondNumber = reverseNumber(secondNumber.toString());
  if(difference < 0)
  {
    difference = difference * -1;
  }
  if(lengthOfFirstNumber == lengthOfSecondNumber)
  {
    length = lengthOfFirstNumber;
  }
  else if(lengthOfFirstNumber > lengthOfSecondNumber)
  {
    length = lengthOfSecondNumber;
  }
  else
  {
    length = lengthOfFirstNumber;
  }
  for(var i = 0; i < length; i++)
  {
    if(finalfirstNumber.charAt(i) == finalsecondNumber.charAt(i) && finalfirstNumber.charAt(i) != 0)
    {
      result = "1"  + result;
    }
    else
    {
      result = "0" + result;
    }
  }
  if(difference > 0)
  {
    for(var i = 0; i < difference; i++)
    {
      result = "0" + result;
    }
  }
  return result;
}
function doNot(num)
{
  var result = "";
  for(var i = 0; i < num.length; i++)
  {
    if(num.charAt(i) == "1")
    {
      if(result != "")
      {
        result += "0";
      }
    }
    else
    {
      result += "1";
    }
  }
  if(result == "")
  {
     result = "0";
  }
  return result;
}
function doOr(firstNumber, secondNumber)
{
  var length;
  var result = "";
  var validity = 0;
  var lengthOfFirstNumber = firstNumber.length;
  var lengthOfSecondNumber = secondNumber.length;
  var finalfirstNumber = reverseNumber(firstNumber.toString());
  var finalsecondNumber = reverseNumber(secondNumber.toString());
  var difference = lengthOfFirstNumber - lengthOfSecondNumber;
  if(difference < 0)
  {
    difference = difference * -1;
  }
  if(lengthOfFirstNumber == lengthOfSecondNumber)
  {
    length = lengthOfSecondNumber;
  }
  else if(lengthOfFirstNumber > lengthOfSecondNumber)
  {
    length = lengthOfSecondNumber;
    validity = 1;
  }
  else
  {
    length = lengthOfFirstNumber;
    validity = 2;
  }
  for(var i = 0; i < length; i++)
  {
    if(finalfirstNumber.charAt(i) == "1" || finalsecondNumber.charAt(i) == "1")
    {
      result = "1"  + result;
    }
    else
    {
      result = "0" + result;
    }
  }
  if(difference > 0)
  {
    for(var i = 0; i < difference; i++)
    {
      if(validity == 1)
      {
        if(finalfirstNumber.charAt(length) == "0")
        {
          result = "0" + result;
        }
        else
        {
          result = "1" + result;
        }
        length++;
      }
      else
      {
        if(finalsecondNumber.charAt(length) == "0")
        {
          result = "0" + result;
        }
        else
        {
          result = "1" + result;
        }
        length++;
      }
    }
  }
  return result;
}
