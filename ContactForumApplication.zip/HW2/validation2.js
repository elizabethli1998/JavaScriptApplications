function validate2() {
    valCheck = true;
    var image1 = getImage(emailCheck(document.forms["contact information"]["email"].value), "email");
    document.getElementById("Email").appendChild(image1);
    var image3 = getImage(phoneCheck(document.forms["contact information"]["number"].value), "number");
    document.getElementById("Number").appendChild(image3);
    var image2 = getImage(addressCheck(document.forms["contact information"]["address"].value), "address");
    document.getElementById("Address").appendChild(image2);


}

function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}

function emailCheck(email) {
    atSplit = email.split('@');
    if (atSplit.length == 2 && alphaNumCheck(atSplit[0])) {
        periodSplit = atSplit[1].split('.')
        if (periodSplit.length == 2 && alphaNumCheck(periodSplit[0] + periodSplit[1])) {
            return true;
        }
    }
    valCheck = false;
    return false;
}
function phoneCheck(number) {
    atSplit = number.split('-');
    var length = atSplit.length;

    if (atSplit.length == 3)
    {
      if(atSplit[0].length === 3 && atSplit[1].length === 3 && atSplit[2].length === 4)
      {
        if(Number(atSplit[0]) != NaN && Number(atSplit[1]) != NaN && Number(atSplit[2]) != NaN)
        {
          return true;
        }
      }
    }
    if(number.length === 10)
    {
      if(Number(number) != NaN)
      {
            return true;
      }
    }
    else
    {
      valCheck = false;
      return false;
    }

}
function addressCheck(address)
{
  atSplit = address.split(',');
  if(atSplit[0].length > 1 && atSplit[1].length === 2)
  {

    if(/^[a-zA-Z]+$/.test(atSplit[0]) && /^[a-zA-Z]+$/.test(atSplit[1]))
    {
          return true;
    }

  }
  else {
    valCheck = false;
    return false;
  }

}
function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
        return false;
    }
}

function deleteCookie( name ) {
  document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
