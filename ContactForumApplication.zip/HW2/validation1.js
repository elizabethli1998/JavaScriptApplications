function validate1() {
    valCheck = true;
    console.log("Test");
    var image1 = getImage(inputCheck(document.forms["contact information"]["firstname"].value), "firstname");
    document.getElementById("FirstName").appendChild(image1);
    var image2 = getImage(inputCheck(document.forms["contact information"]["lastname"].value), "lastname");
    document.getElementById("LastName").appendChild(image2);
    var image3 = getImage(validateChecked(document.forms["contact information"]["gender"].value), "gender");
    document.getElementById("Gender").appendChild(image3);
    var image4 = getImage(validateChecked(document.forms["contact information"]["location"].value), "location");
    document.getElementById("Location").appendChild(image4);

    if(valCheck)
    {
      window.location.href="./validation2.html";
    }

}

function getImage(bool, ID) {
    var image = document.getElementById("image" + ID);
    if (image == null) {
        image = new Image(15, 15);
        image.id = "image" + ID;
    }
    image.src = bool ? './correct.png' : './wrong.png';
    return image;
}

function inputCheck(name) {

    if (alphaNumCheck(name)) {
            return true;
    }
    else {
      valCheck = false;
      return false;
    }
}

function validateChecked(selectOption)
{
  if(selectOption === "None Selected")
  {
      valCheck = false;
    return false;

  }
  if(selectOption != "None Selected")
  {

    return true;
  }

}

function alphaNumCheck(entry) {
    let regex = /^[a-z0-9]+$/i;
    if (entry != null && entry.match(regex)) {
        return true;
    } else {
      valCheck = false;
        return false;
    }
}

function deleteCookie( name ) {
  document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
